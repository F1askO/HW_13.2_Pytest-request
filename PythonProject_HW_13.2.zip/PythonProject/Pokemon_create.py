import requests

Host='https://api.pokemonbattle.ru/v2'
Token='f3b0e2adfce79a51d7d1624a1e69682e'
Header={'Content-Type':'application/json', 'trainer_token':Token}

Body_create_pokemon={
    "name": "Orochimaru",
    "photo_id": 336
}

response_create=requests.post(url=f'{Host}/pokemons', headers=Header, json=Body_create_pokemon)
print(response_create.text)

Pokemon_ID_after_create=response_create.json()['id']
print(Pokemon_ID_after_create)
