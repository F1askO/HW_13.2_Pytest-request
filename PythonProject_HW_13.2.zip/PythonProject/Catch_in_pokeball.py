import requests

Host='https://api.pokemonbattle.ru/v2'
Token='f3b0e2adfce79a51d7d1624a1e69682e'
Header={'Content-Type':'application/json', 'trainer_token':Token}

Body_catch_in_pokeball={
    "pokemon_id": '160674'  
    }

response_catch=requests.post(url=f'{Host}/trainers/add_pokeball', headers=Header, json=Body_catch_in_pokeball)
print(response_catch.text)