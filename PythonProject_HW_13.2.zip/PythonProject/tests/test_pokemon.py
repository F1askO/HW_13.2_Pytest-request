import requests
import pytest

Host='https://api.pokemonbattle.ru/v2'
Token='f3b0e2adfce79a51d7d1624a1e69682e'
Header={'Content-Type':'application/json', 'trainer_token':Token}
Trainer_ID=18136

def test_status_code():
    response=requests.get(url=f'{Host}/pokemons', params={'trainer_id': Trainer_ID})
    assert response.status_code==200

def test_trainer_name():
    response_get_name=requests.get(url=f'{Host}/me', headers=Header)
    assert response_get_name.json()["data"][0]["trainer_name"]=="F1askO"